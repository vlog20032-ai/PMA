import { createClient } from '@supabase/supabase-js'

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL as string,
  import.meta.env.VITE_SUPABASE_ANON_KEY as string
)

export type TipoPorton = 'corredizo' | 'levadizo' | 'batiente' | 'mantenimiento'
export type TipoCliente = 'familia' | 'condominio' | 'constructora'
