import { useEffect, useState, ReactNode } from 'react'

export function navigate(to: string) {
  history.pushState({}, '', to)
  dispatchEvent(new PopStateEvent('popstate'))
  window.scrollTo(0, 0)
}
export function usePath() {
  const [p, setP] = useState(location.pathname)
  useEffect(() => {
    const f = () => setP(location.pathname)
    addEventListener('popstate', f)
    return () => removeEventListener('popstate', f)
  }, [])
  return p
}
export function Link({ to, className, children, onClick }: { to: string; className?: string; children: ReactNode; onClick?: () => void }) {
  return (
    <a href={to} className={className} onClick={e => {
      if (e.metaKey || e.ctrlKey || e.button !== 0) return
      e.preventDefault(); onClick?.(); navigate(to)
    }}>{children}</a>
  )
}
