import { useState, FormEvent } from 'react'
import { supabase, TipoPorton, TipoCliente } from './lib/supabase'

const phoneRe = /^(?:\+?591)?([67]\d{7})$/
const field = 'mt-1 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-3 text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-cyan/60'

export default function Lead({ defaultPorton = '' }: { defaultPorton?: '' | TipoPorton }) {
  const [f, setF] = useState({ nombre: '', celular: '', tipo_porton: defaultPorton as '' | TipoPorton, tipo_cliente: '' as '' | TipoCliente })
  const [err, setErr] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{ ok: boolean; msg: string } | null>(null)

  const show = (ok: boolean, msg: string) => { setToast({ ok, msg }); setTimeout(() => setToast(null), 5000) }

  async function submit(e: FormEvent) {
    e.preventDefault()
    const m = phoneRe.exec(f.celular.replace(/[\s-]/g, ''))
    const er: Record<string, string> = {}
    if (f.nombre.trim().length < 3) er.nombre = 'Escribe tu nombre completo.'
    if (!m) er.celular = 'Ingresa un celular boliviano válido (8 dígitos que empiecen con 6 o 7).'
    if (!f.tipo_porton) er.tipo_porton = 'Elige un tipo de portón.'
    if (!f.tipo_cliente) er.tipo_cliente = 'Elige quién eres.'
    setErr(er)
    if (Object.keys(er).length) return
    setLoading(true)
    const { error } = await supabase.from('leads').insert({
      nombre: f.nombre.trim(), celular: `+591${m![1]}`, tipo_porton: f.tipo_porton, tipo_cliente: f.tipo_cliente
    })
    setLoading(false)
    if (error) return show(false, 'No pudimos enviar tus datos. Intenta de nuevo o escríbenos por WhatsApp.')
    show(true, '¡Listo! Recibimos tu solicitud. Te contactaremos en menos de 24 horas.')
    setF({ nombre: '', celular: '', tipo_porton: '', tipo_cliente: '' })
  }

  const Err = ({ k }: { k: string }) => err[k] ? <p className="mt-1 text-sm text-red-600">{err[k]}</p> : null

  return (
    <>
      <form onSubmit={submit} noValidate className="rounded-2xl bg-white p-6 shadow-2xl ring-1 ring-slate-200 sm:p-8">
        <h2 className="text-2xl font-extrabold">Solicita tu cotización</h2>
        <p className="mt-1 text-sm text-slate-600">Sin compromiso. Respuesta en 24 horas.</p>
        <div className="mt-6 space-y-4">
          <label className="block text-sm font-medium">Nombre
            <input className={field} value={f.nombre} autoComplete="name" onChange={e => setF({ ...f, nombre: e.target.value })} /><Err k="nombre" /></label>
          <label className="block text-sm font-medium">Celular
            <input className={field} inputMode="tel" placeholder="+591 7XXXXXXX" value={f.celular} autoComplete="tel" onChange={e => setF({ ...f, celular: e.target.value })} /><Err k="celular" /></label>
          <label className="block text-sm font-medium">Tipo de portón
            <select className={field} value={f.tipo_porton} onChange={e => setF({ ...f, tipo_porton: e.target.value as TipoPorton })}>
              <option value="">Selecciona…</option><option value="corredizo">Corredizo</option><option value="levadizo">Levadizo</option>
              <option value="batiente">Batiente</option><option value="mantenimiento">Mantenimiento</option></select><Err k="tipo_porton" /></label>
          <label className="block text-sm font-medium">Soy
            <select className={field} value={f.tipo_cliente} onChange={e => setF({ ...f, tipo_cliente: e.target.value as TipoCliente })}>
              <option value="">Selecciona…</option><option value="familia">Familia</option><option value="condominio">Condominio</option><option value="constructora">Constructora</option></select><Err k="tipo_cliente" /></label>
        </div>
        <button disabled={loading} className="mt-6 w-full rounded-lg bg-cyan px-5 py-3.5 font-display font-bold text-navy transition hover:brightness-95 disabled:opacity-60">
          {loading ? 'Enviando…' : 'Solicitar cotización'}
        </button>
      </form>
      {toast && (
        <div role="status" aria-live="polite" className={`fixed bottom-24 left-1/2 z-[60] w-[92%] max-w-md -translate-x-1/2 rounded-xl px-5 py-4 text-sm font-medium text-white shadow-2xl ${toast.ok ? 'bg-emerald-600' : 'bg-red-600'}`}>{toast.msg}</div>
      )}
    </>
  )
}

