import { useEffect, useState, ReactNode } from 'react'
import { Link, usePath } from './router'
import { WA_LINK } from './data'
import { IMG } from './images'

export const Title = ({ t, s }: { t: string; s?: string }) => (
  <div className="mb-10 max-w-2xl"><h2 className="text-3xl font-extrabold sm:text-4xl">{t}</h2>{s && <p className="mt-3 text-slate-600">{s}</p>}</div>
)

export function useTitle(t: string) { useEffect(() => { document.title = t }, [t]) }

export function Img({ k, alt, className = '' }: { k: string; alt: string; className?: string }) {
  const src = IMG[k]
  if (src) return <img src={src} alt={alt} loading="lazy" className={`object-cover ${className}`} />
  return (
    <div role="img" aria-label={alt} className={`flex items-center justify-center bg-gradient-to-br from-navy to-brand ${className}`}>
      <svg viewBox="0 0 120 80" className="w-1/2 max-w-[160px] text-cyan" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true">
        <rect x="10" y="12" width="100" height="56" rx="3" />
        {[30, 50, 70, 90].map(x => <path key={x} d={`M${x} 12v56`} />)}<path d="M10 40h100" />
      </svg>
    </div>
  )
}

export const Cta = () => (
  <section className="bg-brand">
    <div className="mx-auto flex max-w-6xl flex-col items-start gap-4 px-5 py-12 md:flex-row md:items-center md:justify-between">
      <div><h2 className="text-2xl font-extrabold !text-white sm:text-3xl">¿Listo para tu portón automático?</h2>
        <p className="mt-1 text-slate-100">Te enviamos tu cotización en 24 horas.</p></div>
      <Link to="/contacto" className="rounded-lg bg-cyan px-6 py-3 font-bold text-navy">Solicitar cotización</Link>
    </div>
  </section>
)

const NAV = [['/', 'Inicio'], ['/nosotros', 'Nosotros'], ['/productos', 'Productos'], ['/contacto', 'Contáctenos']]

export function Layout({ children }: { children: ReactNode }) {
  const path = usePath()
  const [open, setOpen] = useState(false)
  const on = (to: string) => to === '/' ? path === '/' : path.startsWith(to)
  return (
    <>
      <header className="sticky top-0 z-50 border-b border-white/10 bg-navy/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <Link to="/" className="font-display text-xl font-extrabold text-white">PMA<span className="ml-2 hidden text-sm font-semibold text-cyan lg:inline">Portones Metálicos Automáticos</span></Link>
          <nav className="hidden items-center gap-1 text-sm md:flex">
            {NAV.map(([to, l]) => <Link key={to} to={to} className={`rounded-lg px-3 py-2 ${on(to) ? 'text-cyan' : 'text-slate-200 hover:text-cyan'}`}>{l}</Link>)}
            <Link to="/contacto" className="ml-3 rounded-lg bg-cyan px-4 py-2 font-bold text-navy">Cotizar</Link>
          </nav>
          <button className="rounded-lg p-2 text-white md:hidden" aria-label="Menú" aria-expanded={open} onClick={() => setOpen(!open)}>
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2"><path d={open ? 'M6 6l12 12M18 6L6 18' : 'M4 7h16M4 12h16M4 17h16'} /></svg>
          </button>
        </div>
        {open && <nav className="border-t border-white/10 px-5 py-3 md:hidden">
          {NAV.map(([to, l]) => <Link key={to} to={to} onClick={() => setOpen(false)} className={`block py-3 ${on(to) ? 'text-cyan' : 'text-slate-200'}`}>{l}</Link>)}
        </nav>}
      </header>
      <main>{children}</main>
      <footer className="bg-ink text-slate-300">
        <div className="mx-auto grid max-w-6xl gap-6 px-5 py-12 md:grid-cols-3">
          <div><p className="font-display text-xl font-extrabold text-white">PMA</p><p className="mt-1 text-sm">Portones Metálicos Automáticos</p></div>
          <div><p className="font-semibold text-white">Contacto</p><a href={WA_LINK} className="mt-1 block hover:text-cyan">WhatsApp 79009590</a>
            <Link to="/contacto" className="block hover:text-cyan">Pedir cotización</Link></div>
          <div><p className="font-semibold text-white">Cobertura</p><p className="mt-1 text-sm">Santa Cruz y provincias. Cotizaciones 24h.</p></div>
        </div>
        <p className="border-t border-white/10 py-5 text-center text-xs">© {new Date().getFullYear()} PMA Portones Metálicos Automáticos. Santa Cruz, Bolivia.</p>
      </footer>
      <a href={WA_LINK} target="_blank" rel="noopener noreferrer" aria-label="Escribir por WhatsApp"
        className="fixed bottom-5 right-5 z-50 flex h-14 items-center gap-2 rounded-full bg-[#25D366] px-5 font-semibold text-white shadow-xl transition hover:brightness-95">
        <svg viewBox="0 0 24 24" className="h-6 w-6 fill-current" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.5 15.2L2 22l4.9-1.5A10 10 0 1 0 12 2zm0 18a8 8 0 0 1-4.1-1.1l-.3-.2-2.9.9.9-2.8-.2-.3A8 8 0 1 1 12 20z" /></svg>
        <span className="hidden sm:inline">WhatsApp</span>
      </a>
    </>
  )
}
