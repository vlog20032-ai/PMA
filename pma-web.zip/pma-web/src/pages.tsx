import { Link } from './router'
import Lead from './Lead'
import { Title, Img, Cta, useTitle } from './ui'
import { beneficios, pasos, faqs, PRODUCTOS, WA_LINK } from './data'

const Band = ({ t, s }: { t: string; s: string }) => (
  <section className="bg-navy"><div className="mx-auto max-w-6xl px-5 py-14">
    <h1 className="text-4xl font-extrabold !text-white">{t}</h1><p className="mt-3 max-w-2xl text-lg text-slate-300">{s}</p></div></section>
)

export function Inicio() {
  useTitle('PMA Portones Metálicos Automáticos | Santa Cruz, Bolivia')
  return (
    <>
      <section className="bg-navy">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
          <div>
            <p className="font-medium text-cyan">Santa Cruz, Bolivia</p>
            <h1 className="mt-3 text-4xl font-extrabold leading-tight !text-white sm:text-5xl">Portones que elevan la seguridad y el valor de tu propiedad</h1>
            <p className="mt-5 max-w-xl text-lg text-slate-300">Fabricación e instalación de portones metálicos automáticos para familias, condominios y constructoras. Cotización en 24 horas.</p>
            <div className="mt-8 flex flex-wrap gap-3 text-sm text-slate-200">
              {['1 año de garantía', 'Santa Cruz y provincias', 'Cotizaciones 24h'].map(x => <span key={x} className="rounded-full border border-brand bg-brand/30 px-4 py-1.5">{x}</span>)}
            </div>
          </div>
          <Lead />
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-20">
        <Title t="Por qué elegir PMA" s="Un portón automático es parte de la imagen y la seguridad de tu propiedad." />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {beneficios.map(([t, d]) => <div key={t} className="rounded-xl border border-slate-200 border-t-4 border-t-brand bg-white p-6"><h3 className="text-lg font-bold">{t}</h3><p className="mt-2 text-slate-600">{d}</p></div>)}
        </div>
      </section>
      <section className="bg-white py-20"><div className="mx-auto max-w-6xl px-5">
        <Title t="Nuestros productos" />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PRODUCTOS.map(p => (
            <Link key={p.slug} to={`/productos/${p.slug}`} className="overflow-hidden rounded-xl bg-navy transition hover:bg-brand">
              <Img k={p.slug} alt={p.nombre} className="h-36 w-full" />
              <div className="p-5"><h3 className="text-lg font-bold !text-white">{p.nombre}</h3><p className="mt-2 text-sm text-slate-300">{p.resumen}</p></div>
            </Link>
          ))}
        </div></div></section>
      <section className="mx-auto max-w-6xl px-5 py-20">
        <Title t="Así trabajamos" />
        <ol className="grid gap-6 md:grid-cols-3">
          {pasos.map(([t, d], i) => <li key={t} className="flex gap-4"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand font-display font-bold text-white">{i + 1}</span><div><h3 className="font-bold">{t}</h3><p className="mt-1 text-slate-600">{d}</p></div></li>)}
        </ol>
      </section>
      <section className="bg-brand"><div className="mx-auto max-w-6xl px-5 py-14">
        <h2 className="text-3xl font-extrabold !text-white">1 año de garantía</h2><p className="mt-2 max-w-xl text-slate-100">Respaldamos cada portón que fabricamos e instalamos.</p></div></section>
      <section className="mx-auto max-w-3xl px-5 py-20">
        <Title t="Preguntas frecuentes" />
        <div className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white">
          {faqs.map(([q, a]) => <details key={q} className="group p-5"><summary className="flex cursor-pointer list-none items-center justify-between font-display font-bold text-navy">{q}<span className="ml-4 text-2xl leading-none text-cyan transition group-open:rotate-45">+</span></summary><p className="mt-3 text-slate-600">{a}</p></details>)}
        </div>
      </section>
    </>
  )
}

export function Nosotros() {
  useTitle('Nosotros | PMA Portones Metálicos Automáticos')
  const valores = [['Seguridad', 'Cada portón se piensa para proteger a las personas y los bienes de tu propiedad.'], ['Cumplimiento', 'Cotizamos en 24 horas y trabajamos con tiempos claros.'], ['Cercanía', 'Atendemos en Santa Cruz y provincias, y damos soporte después de la instalación.']]
  return (
    <>
      <Band t="Nosotros" s="Portones metálicos automáticos para familias, condominios y constructoras de Santa Cruz." />
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-20 md:grid-cols-2">
        <div className="space-y-4 text-slate-700">
          <h2 className="text-3xl font-extrabold">Quiénes somos</h2>
          <p>PMA Portones Metálicos Automáticos es una empresa de Santa Cruz, Bolivia, dedicada a fabricar, instalar y mantener portones automáticos.</p>
          <p>Trabajamos con viviendas, condominios y constructoras, con un objetivo simple: que tu acceso sea más seguro, más cómodo y aumente el valor de tu propiedad.</p>
          <p>Todos nuestros trabajos incluyen 1 año de garantía.</p>
        </div>
        <Img k="nosotros" alt="Equipo y trabajos de PMA" className="h-72 w-full rounded-2xl" />
      </section>
      <section className="bg-white py-20"><div className="mx-auto max-w-6xl px-5">
        <Title t="Lo que nos define" />
        <div className="grid gap-5 md:grid-cols-3">{valores.map(([t, d]) => <div key={t} className="rounded-xl border border-slate-200 border-t-4 border-t-brand p-6"><h3 className="text-lg font-bold">{t}</h3><p className="mt-2 text-slate-600">{d}</p></div>)}</div>
      </div></section>
      <Cta />
    </>
  )
}

export function Productos() {
  useTitle('Productos | PMA Portones Metálicos Automáticos')
  return (
    <>
      <Band t="Productos" s="Portones corredizos, levadizos y batientes, además de mantenimiento. Cotiza el que mejor se adapte a tu entrada." />
      <section className="mx-auto grid max-w-6xl gap-6 px-5 py-20 sm:grid-cols-2">
        {PRODUCTOS.map(p => (
          <article key={p.slug} className="overflow-hidden rounded-xl border border-slate-200 bg-white">
            <Img k={p.slug} alt={p.nombre} className="h-48 w-full" />
            <div className="p-6"><h2 className="text-xl font-extrabold">{p.nombre}</h2><p className="mt-2 text-slate-600">{p.resumen}</p>
              <Link to={`/productos/${p.slug}`} className="mt-4 inline-block font-semibold text-brand">Ver detalles →</Link></div>
          </article>
        ))}
      </section>
      <Cta />
    </>
  )
}

export function Producto({ slug }: { slug: string }) {
  const p = PRODUCTOS.find(x => x.slug === slug)
  useTitle(p ? `${p.nombre} | PMA Portones` : 'Producto no encontrado | PMA')
  if (!p) return <section className="px-5 py-24 text-center"><h1 className="text-3xl font-extrabold">Producto no encontrado</h1><Link to="/productos" className="mt-4 inline-block text-brand">Ver todos los productos</Link></section>
  return (
    <>
      <Band t={p.nombre} s={p.resumen} />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-2">
        <div>
          <Img k={p.slug} alt={p.nombre} className="h-64 w-full rounded-2xl" />
          <h2 className="mt-8 text-2xl font-extrabold">Ideal para</h2>
          <ul className="mt-3 space-y-2 text-slate-700">{p.ideal.map(i => <li key={i} className="flex gap-2"><span className="text-cyan">✓</span>{i}</li>)}</ul>
          <p className="mt-6 text-slate-600">Incluye 1 año de garantía. Pide tu cotización y te respondemos en 24 horas.</p>
          <div className="mt-8 flex flex-wrap gap-2 text-sm">{PRODUCTOS.filter(x => x.slug !== p.slug).map(x => <Link key={x.slug} to={`/productos/${x.slug}`} className="rounded-full border border-slate-300 px-4 py-1.5 hover:border-brand">{x.nombre}</Link>)}</div>
        </div>
        <Lead key={p.slug} defaultPorton={p.tipo} />
      </section>
    </>
  )
}

export function Contacto() {
  useTitle('Contáctenos | PMA Portones Metálicos Automáticos')
  return (
    <>
      <Band t="Contáctenos" s="Cuéntanos qué necesitas y te enviamos tu cotización en 24 horas." />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-2">
        <div className="space-y-6">
          <div><h2 className="text-xl font-extrabold">WhatsApp</h2><a href={WA_LINK} target="_blank" rel="noopener noreferrer" className="mt-1 inline-block text-lg font-semibold text-brand">79009590</a></div>
          <div><h2 className="text-xl font-extrabold">Cobertura</h2><p className="mt-1 text-slate-700">Santa Cruz de la Sierra y provincias.</p></div>
          <div><h2 className="text-xl font-extrabold">Cotizaciones</h2><p className="mt-1 text-slate-700">Respondemos en un máximo de 24 horas.</p></div>
        </div>
        <Lead />
      </section>
    </>
  )
}
