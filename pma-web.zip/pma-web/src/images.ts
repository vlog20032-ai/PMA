// FOTOS DEL SITIO. Pega aquí la dirección (URL) de cada foto, o sube la foto a la carpeta public/img
// y escribe '/img/nombre.jpg'. Si dejas una vacía, se muestra una ilustración provisional.
export const IMG: Record<string, string> = {
  nosotros: '',
  'porton-corredizo': '',
  'porton-levadizo': '',
  'porton-batiente': '',
  mantenimiento: ''
}
