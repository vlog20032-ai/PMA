import { usePath } from './router'
import { Layout } from './ui'
import { Inicio, Nosotros, Productos, Producto, Contacto } from './pages'

export default function App() {
  const path = usePath().replace(/\/+$/, '') || '/'
  let page
  if (path === '/nosotros') page = <Nosotros />
  else if (path === '/productos') page = <Productos />
  else if (path.startsWith('/productos/')) page = <Producto slug={path.split('/')[2]} />
  else if (path === '/contacto') page = <Contacto />
  else page = <Inicio />
  return <Layout>{page}</Layout>
}
