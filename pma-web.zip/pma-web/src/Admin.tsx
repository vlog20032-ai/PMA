import { useEffect, useState, FormEvent } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from './lib/supabase'

type Lead = { id: string; nombre: string; celular: string; tipo_porton: string; tipo_cliente: string; created_at: string }
type Perfil = { id: string; nombre: string; email: string; rol: string }
const inp = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 focus:border-brand focus:outline-none focus:ring-2 focus:ring-cyan/60'
const btn = 'rounded-lg bg-brand px-4 py-2.5 font-semibold text-white hover:bg-navy disabled:opacity-60'

export default function Admin() {
  const [session, setSession] = useState<Session | null>(null)
  const [ready, setReady] = useState(false)
  const [perfil, setPerfil] = useState<Perfil | null>(null)
  const [tab, setTab] = useState<'leads' | 'usuarios'>('leads')
  const [leads, setLeads] = useState<Lead[]>([])
  const [users, setUsers] = useState<Perfil[]>([])
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null)
  const [busy, setBusy] = useState(false)
  const [login, setLogin] = useState({ email: '', password: '' })
  const [nu, setNu] = useState({ nombre: '', email: '', password: '', rol: 'vendedor' })

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true) })
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => data.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!session) { setPerfil(null); return }
    supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle().then(({ data }) => setPerfil(data as Perfil | null))
  }, [session])

  async function cargar() {
    const l = await supabase.from('leads').select('*').order('created_at', { ascending: false })
    setLeads((l.data as Lead[]) ?? [])
    if (perfil?.rol === 'admin') {
      const u = await supabase.from('profiles').select('*').order('created_at')
      setUsers((u.data as Perfil[]) ?? [])
    }
  }
  useEffect(() => { if (perfil) cargar() }, [perfil])

  async function entrar(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMsg(null)
    const { error } = await supabase.auth.signInWithPassword(login)
    setBusy(false)
    if (error) setMsg({ ok: false, t: 'Correo o contraseña incorrectos.' })
  }

  async function crear(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMsg(null)
    const { error } = await supabase.rpc('crear_usuario', { p_email: nu.email, p_password: nu.password, p_nombre: nu.nombre, p_rol: nu.rol })
    setBusy(false)
    if (error) return setMsg({ ok: false, t: error.message })
    setMsg({ ok: true, t: 'Usuario creado. Ya puede ingresar con su correo y contraseña.' })
    setNu({ nombre: '', email: '', password: '', rol: 'vendedor' })
    cargar()
  }

  if (!ready) return <p className="p-10 text-center">Cargando…</p>

  if (!session) return (
    <main className="flex min-h-screen items-center justify-center bg-navy px-5">
      <form onSubmit={entrar} className="w-full max-w-sm space-y-4 rounded-2xl bg-white p-8 shadow-2xl">
        <h1 className="text-2xl font-extrabold">Acceso al equipo</h1>
        <input className={inp} type="email" placeholder="Correo" required value={login.email} onChange={e => setLogin({ ...login, email: e.target.value })} />
        <input className={inp} type="password" placeholder="Contraseña" required value={login.password} onChange={e => setLogin({ ...login, password: e.target.value })} />
        {msg && <p className="text-sm text-red-600">{msg.t}</p>}
        <button className={`${btn} w-full`} disabled={busy}>{busy ? 'Entrando…' : 'Ingresar'}</button>
        <a href="/" className="block text-center text-sm text-brand">Volver al sitio</a>
      </form>
    </main>
  )

  if (!perfil) return (
    <main className="p-10 text-center">
      <p>Tu usuario todavía no tiene acceso al panel. Pide al administrador que te habilite.</p>
      <button className={`${btn} mt-4`} onClick={() => supabase.auth.signOut()}>Salir</button>
    </main>
  )

  const admin = perfil.rol === 'admin'
  return (
    <div className="min-h-screen bg-mist">
      <header className="bg-navy text-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-4">
          <p className="font-display text-lg font-extrabold">PMA · Panel <span className="ml-2 text-sm font-normal text-cyan">{perfil.nombre || perfil.email} ({perfil.rol})</span></p>
          <div className="flex gap-2 text-sm">
            <a href="/" className="rounded-lg px-3 py-2 hover:bg-white/10">Ver sitio</a>
            <button onClick={() => supabase.auth.signOut()} className="rounded-lg bg-white/10 px-3 py-2">Salir</button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-5 py-8">
        <div className="mb-6 flex gap-2">
          <button onClick={() => setTab('leads')} className={`rounded-lg px-4 py-2 font-semibold ${tab === 'leads' ? 'bg-brand text-white' : 'bg-white'}`}>Solicitudes ({leads.length})</button>
          {admin && <button onClick={() => setTab('usuarios')} className={`rounded-lg px-4 py-2 font-semibold ${tab === 'usuarios' ? 'bg-brand text-white' : 'bg-white'}`}>Usuarios</button>}
          <button onClick={cargar} className="ml-auto rounded-lg bg-white px-4 py-2">Actualizar</button>
        </div>

        {tab === 'leads' && (
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-slate-100"><tr>{['Fecha', 'Nombre', 'Celular', 'Portón', 'Cliente'].map(h => <th key={h} className="px-4 py-3">{h}</th>)}</tr></thead>
              <tbody>
                {leads.map(l => (
                  <tr key={l.id} className="border-t border-slate-100">
                    <td className="px-4 py-3">{new Date(l.created_at).toLocaleString('es-BO')}</td>
                    <td className="px-4 py-3 font-medium">{l.nombre}</td>
                    <td className="px-4 py-3"><a className="text-brand underline" target="_blank" rel="noopener noreferrer" href={`https://wa.me/${l.celular.replace('+', '')}`}>{l.celular}</a></td>
                    <td className="px-4 py-3 capitalize">{l.tipo_porton}</td>
                    <td className="px-4 py-3 capitalize">{l.tipo_cliente}</td>
                  </tr>
                ))}
                {!leads.length && <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">Aún no hay solicitudes.</td></tr>}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'usuarios' && admin && (
          <div className="grid gap-6 lg:grid-cols-2">
            <form onSubmit={crear} className="space-y-3 rounded-xl border border-slate-200 bg-white p-6">
              <h2 className="text-xl font-extrabold">Crear usuario</h2>
              <input className={inp} placeholder="Nombre" required value={nu.nombre} onChange={e => setNu({ ...nu, nombre: e.target.value })} />
              <input className={inp} type="email" placeholder="Correo" required value={nu.email} onChange={e => setNu({ ...nu, email: e.target.value })} />
              <input className={inp} type="text" placeholder="Contraseña (mínimo 6 caracteres)" required minLength={6} value={nu.password} onChange={e => setNu({ ...nu, password: e.target.value })} />
              <select className={inp} value={nu.rol} onChange={e => setNu({ ...nu, rol: e.target.value })}>
                <option value="vendedor">Vendedor (ve solicitudes)</option><option value="admin">Administrador (además crea usuarios)</option>
              </select>
              {msg && <p className={`text-sm ${msg.ok ? 'text-emerald-700' : 'text-red-600'}`}>{msg.t}</p>}
              <button className={btn} disabled={busy}>{busy ? 'Creando…' : 'Crear usuario'}</button>
            </form>
            <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
              {users.map(u => <li key={u.id} className="flex justify-between px-5 py-3 text-sm"><span><b>{u.nombre || '—'}</b><br />{u.email}</span><span className="capitalize text-slate-500">{u.rol}</span></li>)}
            </ul>
          </div>
        )}
      </main>
    </div>
  )
}
