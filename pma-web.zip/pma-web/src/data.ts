export const WA_LINK = `https://wa.me/59179009590?text=${encodeURIComponent('Hola PMA, quiero cotizar un portón automático.')}`

export const beneficios = [
  ['Seguridad reforzada', 'Estructura metálica robusta y cierre automático que protege a tu familia y tus bienes.'],
  ['Mayor valor de propiedad', 'Un acceso bien terminado mejora la fachada y la plusvalía de tu inmueble.'],
  ['Comodidad diaria', 'Abre y cierra con control remoto, sin bajarte del vehículo.'],
  ['Motores confiables', 'Equipos de uso intensivo, aptos para viviendas, condominios y obras.'],
  ['Diseño a medida', 'Fabricamos según el ancho, el espacio y el estilo de tu entrada.'],
  ['Soporte cercano', 'Mantenimiento y atención técnica en Santa Cruz y provincias.']
]
export const servicios = [
  ['Portón corredizo', 'Se desliza lateralmente. Ideal cuando el espacio frontal es limitado.'],
  ['Portón levadizo', 'Sube y baja en bloque. Práctico para garajes y accesos angostos.'],
  ['Portón batiente', 'Hojas con apertura clásica, motorizadas para mayor comodidad.'],
  ['Mantenimiento', 'Revisión, reparación y ajuste de portones y motores existentes.']
]
export const pasos = [
  ['Cuéntanos tu proyecto', 'Déjanos tus datos y el tipo de portón que necesitas.'],
  ['Recibe tu cotización', 'Te contactamos y te enviamos la propuesta en 24 horas.'],
  ['Instalamos y entregamos', 'Fabricación, instalación y prueba final en tu propiedad.']
]
export const faqs = [
  ['¿En cuánto tiempo recibo mi cotización?', 'Respondemos en un plazo máximo de 24 horas desde que envías el formulario.'],
  ['¿Atienden fuera de Santa Cruz de la Sierra?', 'Sí. Cubrimos Santa Cruz y sus provincias.'],
  ['¿Qué cubre la garantía?', 'Todos nuestros trabajos incluyen 1 año de garantía.'],
  ['¿Instalan en condominios y obras?', 'Sí. Trabajamos con familias, condominios y constructoras.'],
  ['¿Puedo pedir mantenimiento de un portón que ya tengo?', 'Sí. Elige "Mantenimiento" en el formulario y te contactamos.']
]


export type Producto = { slug: string; tipo: 'corredizo' | 'levadizo' | 'batiente' | 'mantenimiento'; nombre: string; resumen: string; ideal: string[] }
export const PRODUCTOS: Producto[] = [
  { slug: 'porton-corredizo', tipo: 'corredizo', nombre: 'Portón corredizo', resumen: 'Se desliza lateralmente sobre un riel y se abre sin ocupar espacio hacia la calle ni hacia el patio.',
    ideal: ['Entradas con poco espacio frontal', 'Viviendas, condominios y accesos de uso frecuente', 'Quien busca una apertura limpia y ordenada'] },
  { slug: 'porton-levadizo', tipo: 'levadizo', nombre: 'Portón levadizo', resumen: 'Sube y baja en bloque, aprovechando la altura y dejando libre el frente del garaje.',
    ideal: ['Garajes con poca profundidad', 'Accesos angostos', 'Fachadas donde se busca un cierre continuo'] },
  { slug: 'porton-batiente', tipo: 'batiente', nombre: 'Portón batiente', resumen: 'De hojas con apertura clásica, motorizadas para abrir y cerrar con control remoto.',
    ideal: ['Entradas con espacio libre al abrir', 'Estilo tradicional y elegante', 'Viviendas y locales'] },
  { slug: 'mantenimiento', tipo: 'mantenimiento', nombre: 'Mantenimiento', resumen: 'Revisión, ajuste y reparación de portones y motores automáticos que ya tienes instalados.',
    ideal: ['Portones que se traban o hacen ruido', 'Motores que dejaron de responder', 'Revisión preventiva para evitar fallas'] }
]
