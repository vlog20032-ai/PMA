-- PMA Portones | SQL 2 de 2: convierte en ADMINISTRADOR al usuario que creaste en Authentication.
-- Cambia el correo de abajo por el tuyo (el mismo que usaste en Authentication > Users).
insert into public.profiles (id, nombre, email, rol)
select id, 'Administrador', email, 'admin' from auth.users
where email = 'TU_CORREO@ejemplo.com'
on conflict (id) do update set rol = 'admin';

select email, rol from public.profiles;  -- debe aparecer tu correo con rol admin
