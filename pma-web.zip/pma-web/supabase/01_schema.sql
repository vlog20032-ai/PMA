-- PMA Portones | SQL 1 de 2: base de datos completa. Pegar UNA vez en Supabase > SQL Editor > Run.
create extension if not exists pgcrypto with schema extensions;

create type tipo_porton as enum ('corredizo','levadizo','batiente','mantenimiento');
create type tipo_cliente as enum ('familia','condominio','constructora');

create table public.leads (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  celular text not null,
  tipo_porton tipo_porton not null,
  tipo_cliente tipo_cliente not null,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nombre text not null default '',
  email text not null default '',
  rol text not null default 'vendedor' check (rol in ('admin','vendedor')),
  created_at timestamptz not null default now()
);

alter table public.leads enable row level security;
alter table public.profiles enable row level security;

create or replace function public.es_staff() returns boolean
language sql security definer stable set search_path = public as
$$ select exists (select 1 from public.profiles where id = auth.uid()) $$;

create or replace function public.es_admin() returns boolean
language sql security definer stable set search_path = public as
$$ select exists (select 1 from public.profiles where id = auth.uid() and rol = 'admin') $$;

-- Visitantes de la web: solo pueden ENVIAR el formulario
create policy "enviar formulario" on public.leads for insert to anon, authenticated with check (true);
-- Equipo: ver leads; solo admin puede borrar
create policy "equipo ve leads" on public.leads for select to authenticated using (public.es_staff());
create policy "admin borra leads" on public.leads for delete to authenticated using (public.es_admin());
-- Perfiles: cada uno ve el suyo; el admin ve todos
create policy "ver perfiles" on public.profiles for select to authenticated using (id = auth.uid() or public.es_admin());

-- Crear usuarios desde dentro de la web (solo admin)
create or replace function public.crear_usuario(p_email text, p_password text, p_nombre text, p_rol text default 'vendedor')
returns uuid language plpgsql security definer set search_path = public, auth, extensions as $$
declare nuevo uuid := gen_random_uuid(); mail text := lower(trim(p_email));
begin
  if not public.es_admin() then raise exception 'Solo el administrador puede crear usuarios'; end if;
  if p_rol not in ('admin','vendedor') then raise exception 'Rol no válido'; end if;
  if length(p_password) < 6 then raise exception 'La contraseña debe tener al menos 6 caracteres'; end if;
  if exists (select 1 from auth.users where email = mail) then raise exception 'Ese correo ya está registrado'; end if;

  insert into auth.users (instance_id,id,aud,role,email,encrypted_password,email_confirmed_at,
    raw_app_meta_data,raw_user_meta_data,created_at,updated_at,confirmation_token,email_change,email_change_token_new,recovery_token)
  values ('00000000-0000-0000-0000-000000000000',nuevo,'authenticated','authenticated',mail,
    crypt(p_password, gen_salt('bf')),now(),'{"provider":"email","providers":["email"]}',
    jsonb_build_object('nombre',p_nombre),now(),now(),'','','','');

  insert into auth.identities (id,user_id,provider_id,identity_data,provider,last_sign_in_at,created_at,updated_at)
  values (gen_random_uuid(),nuevo,nuevo::text,
    jsonb_build_object('sub',nuevo::text,'email',mail,'email_verified',true),'email',now(),now(),now());

  insert into public.profiles (id,nombre,email,rol) values (nuevo,p_nombre,mail,p_rol);
  return nuevo;
end $$;
revoke all on function public.crear_usuario(text,text,text,text) from public, anon;
grant execute on function public.crear_usuario(text,text,text,text) to authenticated;
